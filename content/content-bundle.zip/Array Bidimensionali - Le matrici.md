#NL #Corso0Informatica 

**MOC:** [_Corso 0 Informatica](_Corso%200%20Informatica.md)

E' possibile costruire array a più dimensioni. In particolare, un array **bidimensionale** (comunemente detto **matrice**) è una struttura dati omogenea (come l'[l'array](Che%20cos'è%20un'array.md)) che si estende però su due dimensioni. 

Graficamente è rappresentabile come una **tabella**. 

![](Pasted%20image%2020230116214840.png)

In particolare, un'array bidimensionale di dimensioni N x M è composto da N * M elementi. 

**Esempio:** una matrice M 2x3 è composta da 6 elementi differenti. Ognuno degli elementi elementi può essere identificato utilizzando un doppio indice. 

```` ESEMPIO
M[0][0] M[0][1] M[0][2]
M[1][0] M[1][1] M[1][2]
````


## Collegamento
- [Accedere ad array bidimensionali con NLS](Accedere%20ad%20array%20bidimensionali%20con%20NLS.md)