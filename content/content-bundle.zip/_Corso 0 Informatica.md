#Università #Corso0Informatica #NS

## Notazione Lineare
- [[Notazione Lineare]]
	- [Quando conviene la NLS](Quando%20conviene%20la%20NLS.md)
	- [[Costrutti di base della NLS]]

## Teorema di Bohm-Jacopini
- [[Il teorema di Bohm-Jacopini]] 

## Gli array
- [[Array]]
	- [[Che cos'è un'array]]
	- [[L'indice numerico in un array]]
	- [[NLS e Array]]
	- [[Array Bidimensionali - Le matrici]]
	- [[Accedere ad array bidimensionali con NLS]]

## Rappresentazione delle Informazioni nel calcolatore
