#Corso0Informatica #Università #NL 

**MOC:** [_Corso 0 Informatica](_Corso%200%20Informatica.md)

Gli elementi (celle) di un'array sono identificate da un indice numerico. 

![](Pasted%20image%2020230116213727.png)
Gli indici partono sempre da 0 o da 1. 

Ed è sempre possibile accedere (sia in lettura che in scrittura) alla cella corrispondente al numero dell'indice tramite una notazione simile: 

> a[3]

La notazione sopra, ci permette ad esempio di accedere alla cella con numero di indice 3. 

