
#NL #Corso0Informatica #Università 

**MOC:** [_Corso 0 Informatica](_Corso%200%20Informatica.md)

Per accedere a un [array bidimensionale](Array%20Bidimensionali%20-%20Le%20matrici.md) è sufficiente indicare i due indici che rappresentano le due dimensioni della tabella.

````NLS
a[1][2]
````

Che rappresenta l'elemento della riga 1, colonna 2. 

Per identificare meglio gli elementi, possiamo aiutarci costruendo la nostra matrice: 

| 00 | 01 | 02 | 03 |
|----|----|----|----|
|10 | 11 | 12 | 13 |
| 20 | 21 | 22 | 23 |

L'elemento 00 corrisponde quindi alla prima cella in alto a sinistra. 

**NOTA:** io ho indicato gli indici, ma in realtà, potrebbe starci qualsiasi cosa lì dentro. 