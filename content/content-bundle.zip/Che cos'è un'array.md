#Corso0Informatica #Università #NL

**MOC:** [_Corso 0 Informatica](_Corso%200%20Informatica.md)

Un'array è una struttura dati **omogenea**, che funge da **contenitore** di elementi dello stesso tipo. 

Può essere rappresentato in questo modo: 

![](Pasted%20image%2020230116213547.png)

Sembra un pò come uno di quei dispenser dei farmarci utilizzato per organizzare le medicine della settimana. 

