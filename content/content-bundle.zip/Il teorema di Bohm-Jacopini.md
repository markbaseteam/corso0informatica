#Corso0Informatica #Università #NL

**MOC:** [_Corso 0 Informatica](_Corso%200%20Informatica.md)

Il teorema di Bohm Jacopini afferma che ogni algoritmo può essere costruito utilizzando esclusivamente queste tre strutture: 

1. La Sequenza
2. la Selezione
3. Il ciclo o Interazione (while)

Abbiamo parlato di questi costrutti all'interno di questa nota: [Costrutti di base della NLS](Costrutti%20di%20base%20della%20NLS.md)

Ogni altro tipo di istruzione può essere **sostituita da una combinazione delle tre strutture sopra descritte**.

**NOTA:** Ovviamente i linguaggi di programmazione mettono a disposizione anche altri costrutti, ma di base, questi tre sarebbe più che sufficienti per descrivere qualsiasi algoritmo. 