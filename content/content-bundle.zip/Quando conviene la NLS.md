#NL 

**MOC:** [_Corso 0 Informatica](_Corso%200%20Informatica.md)

La notazione lineare strutturata è decisamente più conveniente in tutti quei casi in cui abbiamo a che fare con algoritmi molto complessi che non sarebbero facilmente rappresentabili tramite diagrammi di flusso, in quanto: 

- Risulterebbero poco leggibili
- Sarebbero soggetti ad errori

Ecco perché in tutte quelle occasioni conviene utilizzare la notazione lineare. Tra l'altro è una tipologia di notazione preferita dai programmatori.  

