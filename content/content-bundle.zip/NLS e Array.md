#Corso0Informatica #Università #NL 

**MOC:** [_Corso 0 Informatica](_Corso%200%20Informatica.md)

E' possibile descrivere l'utilizzo di un'array tramite la notazione lineare. Per farlo, basta utilizzare la notazione con parentesi quadra [] indicando all'interno delle parentesi l'indice della cella del nostro array.

La struttura è simile a questa: 

````NLS
a[1] //Sto leggendo il valore della cella 1 dell'array a

Quindi, ad esempio se a = [1,2,4,5,6,7,8]

Allora con l'espressione a[1] supponendo che il nostro array parta a contare da 0, sto leggendo il numero 2. 

Posso però anche procedere alla scrittura di un elemento come segue:

a[12] <- 110

Sto scrivendo il numero 110 alla posizione 12 del nostro array.

````

Nel caso di [matrici](Array%20Bidimensionali%20-%20Le%20matrici.md) o comunque di array multidimensionali è possibile utilizzare una successione di parentesi quadre in modo da identificare i vari indici della notazione lineare. 
