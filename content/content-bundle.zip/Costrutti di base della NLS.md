#Corso0Informatica #Università #NL 

**MOC:** [_Corso 0 Informatica](_Corso%200%20Informatica.md)

I principali costrutti della notazione lineare sono: 

- **Sequenza:** Equivale ad uno o più blocchi di istruzioni successive
- **Selezione:** Equivale al blocco condizionale del diagramma di flusso
- **Interazione:** Equivalente al blocco condizionale piu uno o piu blocchi di operazioni disposti in modo da formare un ciclo

Questi tre costrutti, secondo quando affermato dal  [teorema di Bohm-Jacopini](Il%20teorema%20di%20Bohm-Jacopini.md) possono essere utilizzare per costruire qualsiasi algoritmo (combinandole adeguatamente).

**NOTA:** avviene i linguaggi di programmazione mettono a disposizione anche costrutti differenti, ma questi tre sono più che sufficienti per descrivere qualsiasi algoritmo. 



![](Pasted%20image%2020230116212830.png)

Quello sopra è un'esempio di sequenza. Si tratta di una serie di istruzioni (azioni) eseguite una dopo l'altra. 

![](Pasted%20image%2020230116212838.png)
Il blocco condizionale corrisponde ad un'istruzione di **selezione**. Tramite la selezione, l'istruzione successiva può essere quella del primo blocco o quella del secondo blocco. 

Il tutto dipende principalmente dal risultato dell'operazione.\

![](Pasted%20image%2020230116212847.png)