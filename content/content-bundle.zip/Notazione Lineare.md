**Parent:** [_Corso 0 Informatica](_Corso%200%20Informatica.md)

